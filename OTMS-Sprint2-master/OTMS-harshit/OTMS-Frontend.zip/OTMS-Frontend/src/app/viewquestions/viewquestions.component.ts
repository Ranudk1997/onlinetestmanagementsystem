import { Component, OnInit } from '@angular/core';
import { Questions } from '../questions';
import { QuestionsService } from '../questions.service';
@Component({
  selector: 'app-viewquestions',
  templateUrl: './viewquestions.component.html',
  styleUrls: ['./viewquestions.component.css']
})
export class ViewquestionsComponent implements OnInit {

  questions:Questions[]=[];
  constructor(private questionsService:QuestionsService) { }
 

  ngOnInit(): void {
    console.log("Am inside view component");
    this.questionsService.viewquestions().subscribe(data=>this.questions=data);
    console.log(this.questions);
  }
  
}
