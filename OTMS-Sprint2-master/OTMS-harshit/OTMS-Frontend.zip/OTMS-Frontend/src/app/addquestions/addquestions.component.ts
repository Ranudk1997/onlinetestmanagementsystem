import { Component, OnInit } from '@angular/core';
import { Questions } from '../questions';
import { QuestionsService } from '../questions.service';

@Component({
  selector: 'app-addquestions',
  templateUrl: './addquestions.component.html',
  styleUrls: ['./addquestions.component.css']
})
export class AddquestionsComponent implements OnInit {
  questions:Questions=new Questions();
  msg:String;
  errorMsg:String;
  constructor(private questionsService:QuestionsService) { }

  ngOnInit(): void {
  }

  addQuestions(){
    console.log(this.questions);
    this.questionsService.addquestions(this.questions).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.questions=new Questions()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}
