import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddquestionsComponent } from './addquestions/addquestions.component';
import {UpdatequestionsComponent} from './updatequestions/updatequestions.component';
import {DeletequestionsComponent} from './deletequestions/deletequestions.component';
import{ViewquestionsComponent} from './viewquestions/viewquestions.component';
const routes: Routes = [
  {path:'addquestions', component:AddquestionsComponent},
  {path:'updatequestions', component:UpdatequestionsComponent},
  {path:'deletequestions', component:DeletequestionsComponent},
  {path:'viewquestions', component:ViewquestionsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
